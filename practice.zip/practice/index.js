// let runAgain = true;

// while (runAgain) {
//     const canVote = (age) => {
      
//         if (age > 18) {
//             return true;
//         } else {
//             return false;
//         }
//     };

//     let age = prompt("Enter your age");
//     age = Number.parseInt(age);
//     if(age<0){
//         alert("Please enter the correct value");
//         break;
//     }

//     if (canVote(age)) {
//         alert("You can vote.");
//     } else {
//         alert("You cannot vote.");
//     }

//     runAgain = confirm("Do you want to run again?");
// }


// const number = prompt("Enter your number here");
// const parsedNumber = Number.parseInt(number);

// if (parsedNumber > 5) {
//     window.location.href = "https://google.com";
// }

// alert("hello");
// setTimeout(function(){
//     alert("Fuck off")

// },2000)


// setTimeout(function() {
//     alert("Operation 1");

//     setTimeout(function() {
//         alert("Operation 2");

//         setTimeout(function() {
//             alert("Operation 3");

//             // ... More nested setTimeouts ...

//             setTimeout(function() {
//                 alert("Final Operation");
//             }, 1000);
//         }, 1000);
//     }, 1000);
// }, 1000);


// setTimeout(function(){
//     alert("Fuck off1");
//     setTimeout(function(){
//         alert("Fuck off2");
//         setTimeout(function(){
//             alert("Fuck off3");
//             setTimeout(function(){
//                 alert("Fuck off4")
            
//             },2000)
        
//         },2000)

    
//     },2000)
    

// },2000)




function sum(a,b){
    return a+b;
}

